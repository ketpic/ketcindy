emathFx.sty$B$O!$(Btxfonts, pxfonts $B$J$I$N%U%)%s%H$N0lIt$r(B
$B$D$^$_?)$$$9$k$?$a$N%U%!%$%k$G$9!#(B

$BEvA3!$$=$l$i$N%U%)%s%H$,%$%s%9%H!<%k$7$F$"$k$3$H$,A0Ds$G$9!#(B

$B8=;~E@$GMQ0U$5$l$F$$$k%*%W%7%g%s$O(B
tx : txfonts
px : pxfonts
eu : euler
xy : Xy-pic $B%Q%C%1!<%8(B
abx: mathabx fonts
$B$N(B5$B<oN`$G$9!#(B

$B3QF#;a$N!VI8=`%$%s%9%H!<%k!W$r$7$F$$$l$P!$(B
   tx, px, eu, abx
$B$O%$%s%9%H!<%k$5$l$^$9$,!$(BXy-pic $B%Q%C%1!<%8$O4^$^$l$F$$$^$;$s$+$i!$(B
$B$3$l$r;H$&$?$a$K$O(B
    CTAN:macros/generic/diagrams/xypic/
$B$+$i%U%!%$%k$r<h$C$F$-$F!$$=$NCf$N%I%-%e%a%s%H(B
    Readme, Install
$B$K$7$?$,$C$F%$%s%9%H!<%k$9$kI,MW$,$"$j$^$9!#(B
