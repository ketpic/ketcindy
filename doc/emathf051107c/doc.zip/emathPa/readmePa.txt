emathPa.sty $B$O!$J?LL:BI87O$NC10L%Y%/%H%k$rG$0U$K<h$k%"%C%U%#%s:BI8$r07$$$^$9!#(B
$B$?$@$7!$(Bzahyou $B4D6-$rA0Ds$H$7!$$=$N6I=j:BI87O$H$$$&0LCVIU$1$G$9!#(B

$B%P!<%8%g%sHV9f$K(B $B&A(B $B$,$D$$$F$$$k4|4V$O(B
$BF0:n$,0U?^$I$*$j$K$$$+$J$+$C$?$j!$(B
    $B;EMM$NBgI}$JJQ99$,9T$o$l$k(B
$B2DG=@-$,6/$$$G$9$+$i!$$4>5CN$N$&$($G$*IU$-9g$$4j$$$^$9!#(B

$B$=$N4D6-L>$O(B azahyou $B$G!$0z?t$O(B
  \begin{azahyou}[#1]#2#3
    #1 : $B%*%W%7%g%s0z?t$G86E@$r;XDj$7$^$9!#!J%G%U%)%k%H$O(B (0,0)$B!K(B
    #2 : x$B<4J}8~$NC10L%Y%/%H%k(B
    #3 : y$B<4J}8~$NC10L%Y%/%H%k(B
    $B%Y%/%H%k@.J,$O$$$:$l$b(B zahyou $B4D6-$N$b$N$H$7$^$9!#(B

$B4D6-Fb$G!$8=;~E@$G$O<!$N%3%^%s%I$,;HMQ$G$-$^$9!#(B
  \azArrowLine
  \azDrawline
  \azHen_ko
  \azKakukigou
  \azkousi
  \azKuromaru
  \azkuromaru
  \azPut
  \aztenretu
  \azTyokusen#1#2
  \azyasen, \azYasen
$B$$$:$l$b!$@\F,;l(B az $B$,$D$$$F$$$^$9!#$=$l$r=|$$$?%3%^%s%I$O(B zahyou $B4D6-$K(B
$B$"$j$^$9$+$i!$$=$l$>$l$N5!G=$ON`?d$7$F$$$?$@$1$k$+$H;W$$$^$9!#(B

$B$J$*!$:BI8JQ495!G=$O(B
  \aztoz#1#2
$B$K$h$j!$(Bazkankyou $B$K$*$1$k6I=j:BI8(B #1 $B$r(B
zahyou$B4D6-$K$*$1$k:BI8$KJQ49$7$?$b$N$,(B #2 $B$N@)8fDV$KLa$j$^$9!#(B
$BH/E8$7$F(B
  \azTenretutoz#1#2
$B$O!$E@NsA4BN$rJQ49$7$^$9!#(B

$BF1:-$N%5%s%W%k%U%!%$%k$K$D$$$F!'(B

ex1.tex azkousi $B$N;HMQNc$G$9!#(B
ex2.tex $B6I=j:BI8$N86E@$rF0$+$9Nc$G$9!#(B
ex3.tex $B:BI8<4$r2sE>$5$;$kNc$G!$J|J*@~$N2sE>$r9T$C$F$$$^$9!#(B
        $B!J$?$@$7!$$3$N%U%!%$%k$O(B perl $B$H$NO"7H5!G=$rI,MW$H$7$^$9!#!K(B
ex4.tex ex3.tex $B$N6I=j:BI87O$N86E@$rF0$+$7$F$$$^$9!#(B
ex5.tex 2$BE@$r7k$VD>@~$rIA2h$9$kNc$G$9!#(B
