emathR.sty $B$O!$(B
	$BJ#?t$N(B .tex $B%U%!%$%k$r$^$H$a$F#1$D$N(B .tex $B%U%!%$%k$r:n$k!$(B
$B$3$H$rL\E*$H$7$F$$$^$9!%(B

  $B$9$J$o$A!$LdBj%i%$%V%i%j$NCf$+$i!$E,Ev$K8+A6$C$FLdBj$rA*Dj$7!$(B
$B$=$l$i$G#1$D$NLdBj=8$J$I$r:n@.$7$h$&!$$H$$$&$M$i$$$G$9!%(B

  LaTeX $B$K$O!$(B\input (or \include) $B$H$$$&%3%^%s%I$,MQ0U$5$l$F$$$^$9!%(B
$B$7$+$7!$$3$3$G$O!$FI$_9~$^$l$k%U%!%$%k<+BN$,%W%j%"%s%V%k$r;}$A!$(B
$BFHN)$7$F%?%$%W%;%C%H$G$-$k(B TeX $B%U%!%$%k$G$"$k!$$H$$$&A[Dj$r$7$F$$$^$9!%(B

$BNc$H$7$F!$(B
	verbatim$B4D6-$r4^$`(B
		00699906.tex
 	$B0z?t$r;}$D%^%/%mDj5A$r4^$`(B
  		00169905.tex
  $B$H$$$&Fs$D$N%U%!%$%k$r(B
  		sampleR.tex
  $B$GFI$_9~$`!$$H$$$&$b$N$r:n$C$F$_$^$7$?!%(B
